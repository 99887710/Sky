package com.bskyb.internettv.thirdparty;

public class TechnicalFailureException extends Exception {
	public TechnicalFailureException(String message, Throwable cause) {
        super(message, cause);
    }
}
