package com.bskyb.internettv.thirdparty;

public class TitleNotFoundException extends Exception {
	
	public TitleNotFoundException(String message, Throwable cause) {
        super(message, cause);
	}
}
